<footer>
                <div class="footer clearfix mb-0 text-muted">
                    
                    <div class="text-center">
                        <p>Copyright &copy; Zennal 2021</p>
                    </div>
                </div>
            </footer>
        </div>
    </div>
    <!-- <script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script> -->
    
    <script src="assets/js/jquery-3.4.1.min.js"></script>
    <script src="assets/vendors/choices.js/choices.min.js"></script>
    <script src="assets/js/feather-icons/feather.min.js"></script>
    <script src="assets/vendors/perfect-scrollbar/perfect-scrollbar.min.js"></script>
    <script src="assets/js/app.js"></script>
    <!-- <script src="assets/vendors/simple-datatables/simple-datatables.js"></script> -->
    <!-- <script src="assets/js/vendors.js"></script> -->
    <script src="assets/vendors/chartjs/Chart.min.js"></script>
    <script src="assets/vendors/apexcharts/apexcharts.min.js"></script>
    <!-- <script src="assets/js/pages/dashboard.js"></script> -->
    <script src="assets/js/main.js"></script>
    <script src="assets/js/wizard.js"></script>
    <script src="assets/js/debounce.js"></script>
    <script src="assets/vendors/sweetalert2/package/dist/sweetalert2.min.js"></script>
    <script src="assets/js/scripts.js"></script>
    <script src="https://cdn.datatables.net/1.10.24/js/jquery.dataTables.min.js"></script>
    <script src='https://cdn.okra.ng/v2/bundle.js'></script>
    <script src="assets/fontawesome/js/all.min.js"></script>
</body>
</html>