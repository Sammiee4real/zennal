
<?php include("includes/sidebar.php");?>
<div id="main">

<?php include("includes/header.php");?>            
<div class="main-content container-fluid">
    <div class="page-title">
        <h3>Select Payment Option</h3>
        <p class="text-subtitle text-muted"> </p>
    </div>


 <section class="section mt-5">
    <section id="basic-vertical-layouts">
    <div class="row match-height">
        <div class="col-md-6 col-12">
        <div class="card">
            <div class="card-header">
            <h4 class="card-title">OPTION</h4>
            </div>
            <div class="card-content">
            <div class="card-body">
                <form class="form form-vertical">
                <div class="form-body">
                    <div class="row">
                     <h5>Full Payment (Discount Available)</h5>
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed pellentesque viverra auctor libero nisl ornare. Sed viverra eget fermentum dictumst pharetra erat donec ut sapien. Proin libero sit amet eleifend sit in venenatis. Morbi orci odio auctor nisl, sit.</p>

                    <div class="col-12 d-flex justify-content-center">
                        <button type="submit" class="btn btn-primary mr-1 mb-1">Select</button>
                    </div>
                    </div>
                </div>
                </form>
            </div>
            </div>
        </div>
        </div>
        <div class="col-md-6 col-12">
        <div class="card">
            <div class="card-header">
            <h4 class="card-title">OPTION</h4>
            </div>
            <div class="card-content">
            <div class="card-body">
                <form class="form form-vertical">
                <div class="form-body">
                    <div class="row">
                    <h5>3 months payment period (30% equity contribution and EMI).</h5>
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed pellentesque viverra auctor libero nisl ornare. Sed viverra eget fermentum dictumst pharetra erat donec ut sapien. Proin libero sit amet eleifend sit in venenatis. Morbi orci odio auctor nisl, sit.</p>
                    <div class="col-12 d-flex justify-content-center">
                        <button type="submit" class="btn btn-primary mr-1 mb-1">Select</button>
                    </div>
                    </div>
                </div>
                </form>
            </div>
            </div>
        </div>
        </div>
    </div>
    </section>
</section>   

</div>
<script type="text/javascript">
    
</script>
<?php include("includes/footer.php");?>
            

