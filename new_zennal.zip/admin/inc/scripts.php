<!-- Bootstrap core JavaScript-->
  <script src="../assets/js/jquery-3.4.1.min.js"></script>
    <!-- Bootstrap-->
    <script src="../assets/js/lib/popper.min.js"></script>
    <script src="../assets/js/lib/bootstrap.min.js"></script>
    <!-- Ionicons -->
    <script type="module" src="https://unpkg.com/ionicons@5.0.0/dist/ionicons/ionicons.js"></script>
    <!-- Owl Carousel -->
    <!-- <script src="../assets/js/plugins/owl-carousel/owl.carousel.min.js"></script> -->
    <!-- jQuery Circle Progress -->
    <!-- <script src="../assets/js/plugins/jquery-circle-progress/circle-progress.min.js"></script> -->
    <!-- Base Js File -->
    <script src="../assets/js/base.js"></script>
    <script src="../assets/js/scripts.js"></script>
    <script src="//cdn.datatables.net/1.10.22/js/jquery.dataTables.min.js"></script>

  <!-- Custom scripts for all pages-->
  <!-- <script src="js/sb-admin-2.min.js"></script> -->

  <!-- Page level plugins -->
  <script src="vendor/chart.js/Chart.min.js"></script>

  <!-- Page level custom scripts -->
  <script src="js/demo/chart-area-demo.js"></script>
  <script src="js/demo/chart-pie-demo.js"></script>

  <script src="//cdnjs.cloudflare.com/ajax/libs/fancybox/2.1.5/jquery.fancybox.min.js"></script>
  <!-- <script src="//cdnjs.cloudflare.com/ajax/libs/fancybox/2.1.5/jquery.fancybox.min.js"></script> -->
  <script src="../assets/vendors/sweetalert2/package/dist/sweetalert2.min.js"></script>
