<?php
	include("config/functions.php");
// 	add_referral('07bf739aba673b233f89d1a25821870d', '56c5ba6bd480b0e56683fe929921bd89
// ', 'vehicle_registration', '50000', 'This referaal bonus is gotten for vehicle registration');
	//add_referral_bonus('vehicle_registration', '20', '07bf739aba673b233f89d1a25821870d');
	// insert_into_wallet('07bf739aba673b233f89d1a25821870d', '6000');

	approve_withdrawal('3ce3e0b60cfd399bc20a8b555bbfedab');
?>