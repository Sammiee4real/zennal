<?php
	include("config/functions.php");
	repayment_cron();
	vechicle_installment_repayment_cron();
?>